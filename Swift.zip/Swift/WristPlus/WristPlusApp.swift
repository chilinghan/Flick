//
//  WristPlusApp.swift
//  WristPlus
//
//  Created by Hunter T on 7/21/24.
//

import SwiftUI

@main
struct WristPlusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }

    }
}
